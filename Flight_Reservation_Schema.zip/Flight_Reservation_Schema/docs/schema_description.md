# Schema Description – Flight Reservation System

**Intern ID:** CITS7424

## Tables Overview

### 1. Airport
Stores information about airports.
- `airport_id` – Primary Key
- `airport_code` – Unique short code (e.g., DEL, BOM)
- `airport_name`, `city`, `country`

### 2. Airline
Stores airline companies.
- `airline_id` – Primary Key
- `airline_code` – Unique code (e.g., AI, 6E)
- `airline_name`

### 3. Passenger
Stores passenger details.
- `passenger_id` – Primary Key
- `first_name`, `last_name`
- `email` (unique), `phone`, `date_of_birth`

### 4. Flight
Stores flight schedule and seat availability.
- `flight_id` – Primary Key
- `flight_number`
- `airline_id` → references Airline
- `departure_airport_id` → references Airport
- `arrival_airport_id` → references Airport
- `departure_time`, `arrival_time`
- `total_seats`, `available_seats`
- `price`

### 5. Booking
Stores passenger reservations.
- `booking_id` – Primary Key
- `passenger_id` → references Passenger
- `flight_id` → references Flight
- `booking_date`
- `seat_number`
- `status` (Confirmed / Cancelled / Pending)
- `total_amount`

## Relationships
- One Airline can have many Flights
- One Airport can be departure or arrival for many Flights
- One Passenger can have many Bookings
- One Flight can have many Bookings

## Notes
This is a simple schema suitable for learning SQL joins, foreign keys, and basic reporting queries.
No triggers, stored procedures, or advanced features are included.
