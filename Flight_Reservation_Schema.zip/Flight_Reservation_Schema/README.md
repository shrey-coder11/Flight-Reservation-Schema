# Flight Reservation Schema

**Intern ID:** CITS7424  
**Project:** Flight Reservation System Database Schema  
**Role:** SQL Intern Project

## Overview
This project contains a simple relational database schema for a Flight Reservation System.  
It includes tables for airports, airlines, flights, passengers, and bookings, along with sample data and basic queries.

## Project Structure
```
Flight_Reservation_Schema/
├── README.md
├── sql/
│   ├── 01_create_schema.sql
│   ├── 02_insert_sample_data.sql
│   └── 03_sample_queries.sql
└── docs/
    └── schema_description.md
```

## How to Use
1. Run `01_create_schema.sql` to create the database and tables.
2. Run `02_insert_sample_data.sql` to load sample data.
3. Run `03_sample_queries.sql` to test common queries.

## Database
- Database name: `flight_reservation`
- Engine: MySQL / MariaDB (compatible with most SQL databases)

## Author
SQL Intern – CITS7424
