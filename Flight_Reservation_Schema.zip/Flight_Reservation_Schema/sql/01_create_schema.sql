-- =====================================================
-- Flight Reservation Schema
-- Intern ID: CITS7424
-- File: 01_create_schema.sql
-- =====================================================

-- Create Database
CREATE DATABASE IF NOT EXISTS flight_reservation;
USE flight_reservation;

-- Drop tables if they exist (for clean re-run)
DROP TABLE IF EXISTS Booking;
DROP TABLE IF EXISTS Flight;
DROP TABLE IF EXISTS Passenger;
DROP TABLE IF EXISTS Airline;
DROP TABLE IF EXISTS Airport;

-- =====================================================
-- Table: Airport
-- =====================================================
CREATE TABLE Airport (
    airport_id      INT PRIMARY KEY AUTO_INCREMENT,
    airport_code    VARCHAR(10) NOT NULL UNIQUE,   -- e.g. DEL, BOM
    airport_name    VARCHAR(100) NOT NULL,
    city            VARCHAR(50) NOT NULL,
    country         VARCHAR(50) NOT NULL
);

-- =====================================================
-- Table: Airline
-- =====================================================
CREATE TABLE Airline (
    airline_id      INT PRIMARY KEY AUTO_INCREMENT,
    airline_code    VARCHAR(10) NOT NULL UNIQUE,   -- e.g. AI, 6E
    airline_name    VARCHAR(100) NOT NULL
);

-- =====================================================
-- Table: Passenger
-- =====================================================
CREATE TABLE Passenger (
    passenger_id    INT PRIMARY KEY AUTO_INCREMENT,
    first_name      VARCHAR(50) NOT NULL,
    last_name       VARCHAR(50) NOT NULL,
    email           VARCHAR(100) UNIQUE,
    phone           VARCHAR(20),
    date_of_birth   DATE
);

-- =====================================================
-- Table: Flight
-- =====================================================
CREATE TABLE Flight (
    flight_id           INT PRIMARY KEY AUTO_INCREMENT,
    flight_number       VARCHAR(20) NOT NULL,
    airline_id          INT NOT NULL,
    departure_airport_id INT NOT NULL,
    arrival_airport_id  INT NOT NULL,
    departure_time      DATETIME NOT NULL,
    arrival_time        DATETIME NOT NULL,
    total_seats         INT NOT NULL DEFAULT 150,
    available_seats     INT NOT NULL DEFAULT 150,
    price               DECIMAL(10,2) NOT NULL,
    
    FOREIGN KEY (airline_id) REFERENCES Airline(airline_id),
    FOREIGN KEY (departure_airport_id) REFERENCES Airport(airport_id),
    FOREIGN KEY (arrival_airport_id) REFERENCES Airport(airport_id)
);

-- =====================================================
-- Table: Booking
-- =====================================================
CREATE TABLE Booking (
    booking_id      INT PRIMARY KEY AUTO_INCREMENT,
    passenger_id    INT NOT NULL,
    flight_id       INT NOT NULL,
    booking_date    DATETIME DEFAULT CURRENT_TIMESTAMP,
    seat_number     VARCHAR(10),
    status          VARCHAR(20) DEFAULT 'Confirmed',  -- Confirmed, Cancelled, Pending
    total_amount    DECIMAL(10,2) NOT NULL,
    
    FOREIGN KEY (passenger_id) REFERENCES Passenger(passenger_id),
    FOREIGN KEY (flight_id) REFERENCES Flight(flight_id)
);

-- =====================================================
-- End of Schema Creation
-- =====================================================
