-- =====================================================
-- Flight Reservation Schema - Sample Data
-- Intern ID: CITS7424
-- File: 02_insert_sample_data.sql
-- =====================================================

USE flight_reservation;

-- =====================================================
-- Insert Airports
-- =====================================================
INSERT INTO Airport (airport_code, airport_name, city, country) VALUES
('DEL', 'Indira Gandhi International Airport', 'Delhi', 'India'),
('BOM', 'Chhatrapati Shivaji Maharaj International Airport', 'Mumbai', 'India'),
('BLR', 'Kempegowda International Airport', 'Bangalore', 'India'),
('MAA', 'Chennai International Airport', 'Chennai', 'India'),
('HYD', 'Rajiv Gandhi International Airport', 'Hyderabad', 'India'),
('CCU', 'Netaji Subhas Chandra Bose International Airport', 'Kolkata', 'India');

-- =====================================================
-- Insert Airlines
-- =====================================================
INSERT INTO Airline (airline_code, airline_name) VALUES
('AI', 'Air India'),
('6E', 'IndiGo'),
('UK', 'Vistara'),
('SG', 'SpiceJet'),
('G8', 'Go First');

-- =====================================================
-- Insert Passengers
-- =====================================================
INSERT INTO Passenger (first_name, last_name, email, phone, date_of_birth) VALUES
('Rahul', 'Sharma', 'rahul.sharma@email.com', '9876543210', '1990-05-15'),
('Priya', 'Patel', 'priya.patel@email.com', '9876543211', '1992-08-22'),
('Amit', 'Kumar', 'amit.kumar@email.com', '9876543212', '1988-11-03'),
('Sneha', 'Reddy', 'sneha.reddy@email.com', '9876543213', '1995-01-18'),
('Vikram', 'Singh', 'vikram.singh@email.com', '9876543214', '1985-07-30'),
('Ananya', 'Iyer', 'ananya.iyer@email.com', '9876543215', '1993-12-09');

-- =====================================================
-- Insert Flights
-- =====================================================
INSERT INTO Flight (flight_number, airline_id, departure_airport_id, arrival_airport_id, 
                   departure_time, arrival_time, total_seats, available_seats, price) VALUES
('AI101', 1, 1, 2, '2025-10-15 08:00:00', '2025-10-15 10:15:00', 180, 175, 5500.00),
('6E202', 2, 2, 3, '2025-10-15 11:30:00', '2025-10-15 13:00:00', 180, 160, 4200.00),
('UK303', 3, 1, 3, '2025-10-16 06:45:00', '2025-10-16 09:30:00', 160, 150, 6800.00),
('SG404', 4, 3, 4, '2025-10-16 14:00:00', '2025-10-16 15:45:00', 180, 170, 3900.00),
('AI505', 1, 2, 1, '2025-10-17 09:00:00', '2025-10-17 11:20:00', 180, 180, 5200.00),
('6E606', 2, 4, 5, '2025-10-17 16:30:00', '2025-10-17 18:00:00', 180, 165, 4500.00),
('UK707', 3, 5, 1, '2025-10-18 07:15:00', '2025-10-18 09:45:00', 160, 155, 6100.00),
('G8808', 5, 1, 6, '2025-10-18 12:00:00', '2025-10-18 14:30:00', 180, 140, 4800.00);

-- =====================================================
-- Insert Bookings
-- =====================================================
INSERT INTO Booking (passenger_id, flight_id, seat_number, status, total_amount) VALUES
(1, 1, '12A', 'Confirmed', 5500.00),
(2, 1, '12B', 'Confirmed', 5500.00),
(3, 2, '15C', 'Confirmed', 4200.00),
(4, 3, '08A', 'Confirmed', 6800.00),
(5, 4, '22F', 'Confirmed', 3900.00),
(1, 5, '10D', 'Confirmed', 5200.00),
(6, 6, '05A', 'Pending', 4500.00),
(2, 7, '18B', 'Confirmed', 6100.00),
(3, 8, '03C', 'Cancelled', 4800.00);

-- =====================================================
-- End of Sample Data
-- =====================================================
