-- =====================================================
-- Flight Reservation Schema - Sample Queries
-- Intern ID: CITS7424
-- File: 03_sample_queries.sql
-- =====================================================

USE flight_reservation;

-- 1. List all flights with airline name and airport details
SELECT 
    f.flight_number,
    a.airline_name,
    dep.airport_code AS departure_airport,
    dep.city AS departure_city,
    arr.airport_code AS arrival_airport,
    arr.city AS arrival_city,
    f.departure_time,
    f.arrival_time,
    f.available_seats,
    f.price
FROM Flight f
JOIN Airline a ON f.airline_id = a.airline_id
JOIN Airport dep ON f.departure_airport_id = dep.airport_id
JOIN Airport arr ON f.arrival_airport_id = arr.airport_id
ORDER BY f.departure_time;

-- 2. Show all confirmed bookings with passenger and flight details
SELECT 
    b.booking_id,
    CONCAT(p.first_name, ' ', p.last_name) AS passenger_name,
    p.email,
    f.flight_number,
    a.airline_name,
    b.seat_number,
    b.booking_date,
    b.total_amount,
    b.status
FROM Booking b
JOIN Passenger p ON b.passenger_id = p.passenger_id
JOIN Flight f ON b.flight_id = f.flight_id
JOIN Airline a ON f.airline_id = a.airline_id
WHERE b.status = 'Confirmed'
ORDER BY b.booking_date;

-- 3. Find flights from Delhi (DEL) to any destination
SELECT 
    f.flight_number,
    a.airline_name,
    arr.city AS destination,
    f.departure_time,
    f.price,
    f.available_seats
FROM Flight f
JOIN Airline a ON f.airline_id = a.airline_id
JOIN Airport dep ON f.departure_airport_id = dep.airport_id
JOIN Airport arr ON f.arrival_airport_id = arr.airport_id
WHERE dep.airport_code = 'DEL'
ORDER BY f.departure_time;

-- 4. Count number of bookings per flight
SELECT 
    f.flight_number,
    a.airline_name,
    COUNT(b.booking_id) AS total_bookings
FROM Flight f
JOIN Airline a ON f.airline_id = a.airline_id
LEFT JOIN Booking b ON f.flight_id = b.flight_id
GROUP BY f.flight_id, f.flight_number, a.airline_name
ORDER BY total_bookings DESC;

-- 5. List passengers who have more than one booking
SELECT 
    CONCAT(p.first_name, ' ', p.last_name) AS passenger_name,
    p.email,
    COUNT(b.booking_id) AS booking_count
FROM Passenger p
JOIN Booking b ON p.passenger_id = b.passenger_id
GROUP BY p.passenger_id, p.first_name, p.last_name, p.email
HAVING COUNT(b.booking_id) > 1;

-- 6. Total revenue from confirmed bookings
SELECT 
    SUM(total_amount) AS total_revenue
FROM Booking
WHERE status = 'Confirmed';

-- 7. Flights with available seats less than 20
SELECT 
    f.flight_number,
    a.airline_name,
    f.available_seats,
    f.departure_time
FROM Flight f
JOIN Airline a ON f.airline_id = a.airline_id
WHERE f.available_seats < 20
ORDER BY f.available_seats;

-- 8. Booking details for a specific passenger (example: Rahul Sharma)
SELECT 
    b.booking_id,
    f.flight_number,
    dep.city AS from_city,
    arr.city AS to_city,
    f.departure_time,
    b.seat_number,
    b.status,
    b.total_amount
FROM Booking b
JOIN Passenger p ON b.passenger_id = p.passenger_id
JOIN Flight f ON b.flight_id = f.flight_id
JOIN Airport dep ON f.departure_airport_id = dep.airport_id
JOIN Airport arr ON f.arrival_airport_id = arr.airport_id
WHERE p.first_name = 'Rahul' AND p.last_name = 'Sharma';

-- =====================================================
-- End of Sample Queries
-- =====================================================
